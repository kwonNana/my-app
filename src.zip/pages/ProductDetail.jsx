import React from 'react';

function ProductDetail(props) {
    return (
        <div>
            ProductDetail
        </div>
    );
}

export default ProductDetail;