import React from 'react';

function NewProduct(props) {
    return (
        <div>
            NewProduct
        </div>
    );
}

export default NewProduct;