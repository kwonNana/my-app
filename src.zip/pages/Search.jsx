import React from 'react';
import SearchItem from '../component/SearchItem';

function Search(props) {
    return (
        <div>
            <SearchItem/>
        </div>
    );
}

export default Search;