import React from 'react';

function Allproduct(props) {
    return (
        <div>
            Allproduct
        </div>
    );
}

export default Allproduct;