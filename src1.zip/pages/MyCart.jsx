import React from 'react';

function MyCart(props) {
    return (
        <div>
            MyCart
        </div>
    );
}

export default MyCart;