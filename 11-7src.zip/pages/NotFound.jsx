import React from 'react';

function NotFound(props) {
    return (
        <div>
            <h1>Not Found!</h1>
        </div>
    );
}
<h1>Not Found!</h1>
export default NotFound;